import React, {useState} from 'react';

const App = () => {
    const [steps,setSteps] = useState(0);

    return (
    <div className="container">
      <p>Today you've taken {steps} steps!</p>
      <button onClick={() => setSteps(steps + 1)}>Click Me</button>

      {steps >= 5 ? (
        <div style={{ backgroundColor: '#d4edda', padding: '10px', borderRadius: '5px' }}>
          <h3>🎉 Bravo!</h3>
          <p>Ai atins obiectivul minim de 5 pași!</p>
        </div>
      ) : (
        <div style={{ backgroundColor: '#f8d7da', padding: '10px', borderRadius: '5px' }}>
          <p>Încă nu ai atins obiectivul. Mai ai nevoie de {5 - steps} pași.</p>
        </div>)}

    </div>
  );
}

export default App;