
const About = () => {

    return (
        <>
        <p>This is about section!</p>
        </>
    );
}

export default About;