export const SERVER = 'http://localhost:8080'
