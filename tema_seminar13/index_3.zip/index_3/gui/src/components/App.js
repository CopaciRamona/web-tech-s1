import BookList from './BookList'

function App () {
  return (
    <div>
      <BookList />
    </div>
  )
}

export default App
